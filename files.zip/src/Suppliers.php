<?php

$suppliers = ['https://bit.ly/3GlDsSw', 'https://bit.ly/3Gr5T1t'];
